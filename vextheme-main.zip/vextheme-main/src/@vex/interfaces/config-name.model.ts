export enum ConfigName {
  apollo = 'vex-layout-apollo',
  zeus = 'vex-layout-zeus',
  hermes = 'vex-layout-hermes',
  poseidon = 'vex-layout-poseidon',
  ares = 'vex-layout-ares',
  ikaros = 'vex-layout-ikaros',
}
