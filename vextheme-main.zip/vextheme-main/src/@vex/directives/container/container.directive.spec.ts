import { ContainerDirective } from './container.directive';

describe('ContainerDirective', () => {
  it('should create an instance', () => {
    const directive = new ContainerDirective();
    expect(directive).toBeTruthy();
  });
});
