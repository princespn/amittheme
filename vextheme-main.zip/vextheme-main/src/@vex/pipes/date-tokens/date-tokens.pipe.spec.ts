import { DateTokensPipe } from './date-tokens.pipe';

describe('DateTokensPipe', () => {
  it('create an instance', () => {
    const pipe = new DateTokensPipe();
    expect(pipe).toBeTruthy();
  });
});
